import sqlite3
from flask_restful import Resource,
from models.evaluation import EvalModel
from eval_functions import EvaluationFunctions

class Evaluate(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('model_path',
        type=String,
        required=True,
        help="Please provide a model path"
    )
    parser.add_argument('dataset_path',
        type=String,
        required=True,
        help="Please provide a datset path"
    )
    parser.add_argument('model_type',
        type=String,
        required=True,
        help="Please define the type of model"
    )

    def get(self,eval_id):


    def post(self,name):
        if EvalModel.find_by_name(name):
            return {"message":"An evaluation with name {} already exists".format(name)}, 400

        data = Evaluate.parser.parse_args()

        item = EvalModel(name, **data)

        try:
            item.save_to_db()
        except:
            return {"message":"An error occured inserting the evaluation"}, 500

        return item.json(), 201
